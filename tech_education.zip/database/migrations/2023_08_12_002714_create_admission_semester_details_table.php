<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('admission_semester_details', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('admission_id');
            $table->unsignedBigInteger('admission_details_id');
            $table->unsignedBigInteger('semester_id');
            $table->integer('code_no');
            $table->string('crouse_title');
            $table->integer('credit');
            $table->foreign('admission_id')->references('id')->on('admissions')->onDelete('cascade');
            $table->foreign('admission_details_id')->references('id')->on('admission_details')->onDelete('cascade');
            $table->foreign('semester_id')->references('id')->on('admission_semesters')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('admission_semester_details');
    }
};
