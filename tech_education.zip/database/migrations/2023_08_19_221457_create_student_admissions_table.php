<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
	/**
	 * Run the migrations.
	 */
	public function up(): void
	{
		Schema::create('student_admissions', function (Blueprint $table) {
			$table->id();
			$table->unsignedBigInteger('subject_id');
			$table->unsignedBigInteger('payment_id')->nullable();
			$table->unsignedBigInteger('batch_id')->nullable();
			$table->string('name');
			$table->bigInteger('nid');
			$table->integer('number');
			$table->integer('optional_number')->nullable();
			$table->string('email');
			$table->float('ssc_result');
			$table->float('hsc_result');
			$table->string('certificate')->default('default.png');
			$table->string('religion');
			$table->string('gender');
			$table->string('present_address')->nullable();
			$table->string('permanent_address')->nullable();
			$table->string('blood_group')->nullable();
			$table->string('father_name')->nullable();
			$table->string('mother_name')->nullable();
			$table->bigInteger('father_nid')->nullable();
			$table->bigInteger('mother_nid')->nullable();
			$table->integer('guardian_number')->nullable();
			$table->integer('payment_type')->nullable();
			$table->string('transaction_number')->default('default.png')->nullable();
			$table->integer('roll')->unique()->nullable()->default('1');
			$table->string('register')->unique()->nullable()->default(0);
			$table->string('image')->default('default.png');
			$table->boolean('is_approved')->default(true);
			$table->enum('admission', ['offline', 'online'])->default('offline');
			$table->foreign('subject_id')->references('id')->on('admission_details')->onDelete('cascade');
			$table->foreign('payment_id')->references('id')->on('payments')->onDelete('cascade');
			$table->foreign('batch_id')->references('id')->on('batches')->onDelete('cascade');
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 */
	public function down(): void
	{
		Schema::dropIfExists('student_admissions');
	}
};
