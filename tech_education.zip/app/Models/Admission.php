<?php

namespace App\Models;

use App\Models\Exam;
use App\Models\Result;
use App\Models\Teacher;
use App\Models\AdmissionDetails;
use App\Models\AdmissionSemester;
use Illuminate\Database\Eloquent\Model;
use App\Models\AdmissionSemesterDetails;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Admission extends Model
{
	use HasFactory;
	protected $guarded = [];

	/**
	 * Get the details that owns the Admission
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function details(): BelongsTo
	{
		return $this->belongsTo(AdmissionDetails::class);
	}

	/**
	 * Get the semester that owns the Admission
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function semester(): BelongsTo
	{
		return $this->belongsTo(AdmissionSemester::class);
	}

	/**
	 * Get the semester_datails that owns the Admission
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function semester_datails(): BelongsTo
	{
		return $this->belongsTo(AdmissionSemesterDetails::class);
	}


	/**
	 * Get the results that owns the Admission
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function results(): BelongsTo
	{
		return $this->belongsTo(Result::class);
	}

	/**
	 * Get the classRoutine that owns the Admission
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function classRoutine(): BelongsTo
	{
		return $this->belongsTo(ClassRoutine::class);
	}

	/**
	 * Get the examRoutine that owns the Admission
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function examRoutine(): BelongsTo
	{
		return $this->belongsTo(Exam::class);
	}

	/**
	 * Get all of the teacher for the Admission
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\HasMany
	 */
	public function teacher(): HasMany
	{
		return $this->hasMany(Teacher::class);
	}
}
