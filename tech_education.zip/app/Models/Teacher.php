<?php

namespace App\Models;

use App\Models\Admission;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Teacher extends Model
{
	use HasFactory;
	protected $guarded = [];



	/**
	 * Get the admission that owns the AdmissionDetails
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function department(): BelongsTo
	{
		return $this->belongsTo(Admission::class, 'department_id', 'id');
	}

	/**
	 * Get the teacherType that owns the Teacher
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function teacherType(): BelongsTo
	{
			return $this->belongsTo(TeacherTab::class, 'tab_id', 'id');
	}
}
