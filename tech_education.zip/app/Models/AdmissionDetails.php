<?php

namespace App\Models;

use App\Models\Batch;
use App\Models\Admission;
use App\Models\StudentAdmission;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AdmissionDetails extends Model
{
	use HasFactory;
	protected $guarded = [];


	/**
	 * Get the admission that owns the AdmissionDetails
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function admission(): BelongsTo
	{
		return $this->belongsTo(Admission::class, 'admission_id', 'id');
	}


	/**
	 * Get the students that owns the AdmissionDetails
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function subject_all(): BelongsTo
	{
		return $this->belongsTo(StudentAdmission::class);
	}

	/**
	 * Get the batchs that owns the AdmissionDetails
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function batchs(): BelongsTo
	{
		return $this->belongsTo(Batch::class);
	}
}
