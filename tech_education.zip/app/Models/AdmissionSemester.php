<?php

namespace App\Models;

use App\Models\Admission;
use App\Models\AdmissionDetails;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AdmissionSemester extends Model
{
	use HasFactory;
	protected $guarded = [];

	/**
	 * Get the admission that owns the AdmissionDetails
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function admission(): BelongsTo
	{
		return $this->belongsTo(Admission::class);
	}

	/**
	 * Get the admission_details that owns the AdmissionDetails
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function admission_details(): BelongsTo
	{
		return $this->belongsTo(AdmissionDetails::class);
	}
}
