<?php

namespace App\Models;

use App\Models\Admission;
use App\Models\StudentAdmission;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Payment extends Model
{
	use HasFactory;
	protected $guarded = [];

	/**
	 * Get the admission that owns the Payment
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function admission(): BelongsTo
	{
		return $this->belongsTo(Admission::class, 'payment_id', 'id');
	}

	/**
	 * Get the student that owns the Payment
	 *
	 * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
	 */
	public function student(): BelongsTo
	{
			return $this->belongsTo(StudentAdmission::class);
	}
}
