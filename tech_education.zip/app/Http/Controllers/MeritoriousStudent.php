<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MeritoriousStudent extends Controller
{
    //
}
