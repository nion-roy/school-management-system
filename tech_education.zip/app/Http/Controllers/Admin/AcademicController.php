<?php

namespace App\Http\Controllers\Admin;

use App\Models\Academic;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Controllers\Controller;
use App\Models\AcademicType;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Storage;

class AcademicController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index()
	{
		$academic = Academic::latest()->get();
		return view('admin.academic.index', compact('academic'));
	}

	/**
	 * Show the form for creating a new resource.
	 */
	public function create()
	{
		$types = AcademicType::get();
		return view('admin.academic.create', compact('types'));
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(Request $request)
	{
		$this->validate($request, [
			'pdf'		=> 'required|mimes:pdf'
		]);

		$pdfFile = $request->file('pdf');
		$currentData = Carbon::now()->toDateString();

		if (isset($pdfFile)) {
			$pdfName = 'academic-information-' . $currentData . '.' . $pdfFile->getClientOriginalExtension();
			// check post dir is exists
			if (!Storage::disk('public')->exists('academic-information')) {
				Storage::disk('public')->makeDirectory('academic-information');
			}
			// pdf for add in exists
			$pdfData = file_get_contents($pdfFile);
			Storage::disk('public')->put('academic-information/' . $pdfName, $pdfData);
		} else {
			$pdfName = 'default.pdf';
		}

		// return $request;

		$academic = new Academic();
		$academic->academic_id  = $request->academic_id;
		$academic->pdf = $pdfName;

		if (isset($request->status)) {
			$academic->status = true;
		} else {
			$academic->status = false;
		}

		$academic->save();

		Toastr::success('You have Create the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Display the specified resource.
	 */
	public function show(string $id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 */
	public function edit(string $id)
	{
		$academicType = AcademicType::get();
		$academic = Academic::findOrFail($id);
		return view('admin.academic.edit', compact('academicType', 'academic'));
	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update(Request $request, string $id)
	{
		$this->validate($request, [
			'pdf'		=> 'mimes:pdf'
		]);

		$academic = Academic::findOrFail($id);
		$pdfFile = $request->file('pdf');
		$currentData = Carbon::now()->toDateString();

		if (isset($pdfFile)) {
			$pdfName = 'academic-information-' . $currentData . '.' . $pdfFile->getClientOriginalExtension();
			// check post dir is exists
			if (!Storage::disk('public')->exists('academic-information')) {
				Storage::disk('public')->makeDirectory('academic-information');
			}
			// check old image & delete is exists
			if (Storage::disk('public')->exists('academic-information/' . $academic->pdf)) {
				Storage::disk('public')->delete('academic-information/' . $academic->pdf);
			}
			// pdf for add in exists
			$pdfData = file_get_contents($pdfFile);
			Storage::disk('public')->put('academic-information/' . $pdfName, $pdfData);
		} else {
			$pdfName = $academic->pdf;
		}

		$academic->academic_id = $request->academic_id;
		$academic->pdf = $pdfName;

		if (isset($request->status)) {
			$academic->status = true;
		} else {
			$academic->status = false;
		}

		$academic->save();

		Toastr::success('You have Update the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(string $id)
	{
		$academic = Academic::findOrFail($id);
		// check old image & delete is exists
		if (Storage::disk('public')->exists('academic-information/' . $academic->file)) {
			Storage::disk('public')->delete('academic-information/' . $academic->file);
		}
		$academic->delete();
		Toastr::success('You have Delete the data Successfully', 'Success');
		return redirect()->back();
	}
}
