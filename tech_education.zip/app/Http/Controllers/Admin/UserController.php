<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use App\Models\Batch;
use App\Models\Subject;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\UserStudent;
use App\Models\UserTeacher;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index()
	{
		$admin = User::where('role', 'admin')->count();
		$subAdmin = User::where('role', 'sub-admin')->count();
		$admins = User::where('role', 'admin')->orWhere('role', 'sub-admin')->latest()->get();
		return view('admin.user.admin.index', compact('admins', 'admin', 'subAdmin'));
	}

	/**
	 * Show the form for creating a new resource.
	 */
	public function create()
	{
		$subjects = Subject::where('status', true)->latest()->get();
		$classes = Batch::where('status', true)->get();
		return view('admin.user.admin.create', compact('subjects', 'classes'));
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(Request $request)
	{
		// return $request;

		$this->validate($request, [
			'role'		=> 'required|string',
			'email'		=> 'required|email|unique:users',
			'contact'		=> 'required|numeric|unique:users',
		]);

		// get form image
		$image = $request->file('image');
		$slug = Str::slug($request->name);

		if (isset($image)) {
			// make unique name for image
			$imageName = $slug . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
			// check post dir is exists
			if (!Storage::disk('public')->exists('user')) {
				Storage::disk('public')->makeDirectory('user');
			}
			// resize image for post add upload
			$resizeImage = Image::make($image)->resize(160, 160)->stream();
			Storage::disk('public')->put('user/' . $imageName, $resizeImage);
		} else {
			$imageName = 'default.png';
		}

		$user = new User();
		$user->name = $request->name;
		$user->role = $request->role;
		$user->email = $request->email;
		$user->contact = $request->contact;
		$user->image = $imageName;
		$user->password = Hash::make('12345678');

		if (isset($request->status)) {
			if ($request->role == 'admin' || $request->role == 'sub-admin') {
				$user->status = false;
			} else {
				$user->status = true;
			}
		} else {
			$user->status = false;
		}

		$user->save();

		if ($user->role == 'teacher') {


			$teacher = new UserTeacher();
			$teacher->user_id = $user->id;
			$teacher->subject_id = $request->subject_id;
			$teacher->title 		=	$request->title;
			$teacher->facebook 		=	$request->facebook;
			$teacher->twitter 		=	$request->twitter;
			$teacher->instagram 		=	$request->instagram;
			$teacher->save();
		}


		if ($user->role == 'user') {
			# code...
			$student = new UserStudent();
			$student->user_id = $user->id;
			$student->class_id = $request->class_id;
			$student->roll = $request->roll;
			$student->register = $request->register;
			$student->father_name = $request->father_name;
			$student->mother_name = $request->mother_name;
			$student->guardian_contact = $request->guardian_contact;
			$student->present_address = $request->present_address;
			$student->parament_address = $request->parament_address;
			$student->session = $request->session;
			$student->gender  =  $request->gender;
			$student->student_type  =  $request->student_type;
			$student->save();
		}




		// $user->class_id = $request->class_id;
		// $user->subject_id = $request->subject_id;
		// $user->title 		=	$request->title;
		// $user->facebook 		=	$request->facebook;
		// $user->twitter 		=	$request->twitter;
		// $user->instagram 		=	$request->instagram;

		// $user->roll = $request->roll;
		// $user->register = $request->register;
		// $user->father_name = $request->father_name;
		// $user->mother_name = $request->mother_name;
		// $user->guardian_contact = $request->guardian_contact;
		// $user->present_address = $request->present_address;
		// $user->parament_address = $request->parament_address;
		// $user->session = $request->session;
		// $user->gender  =  $request->gender;
		// $user->teacher_type  =  true;



		// if (isset($request->status)) {
		// 	$user->status = true;
		// } else {
		// 	$user->status = true;
		// }


		Toastr::success('You have Create the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Display the specified resource.
	 */
	public function show(string $id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 */
	public function edit(string $id)
	{
		$user = User::findOrFail($id);
		$subjects = Subject::where('status', true)->latest()->get();
		$classes = Batch::where('status', true)->get();
		return view('admin.user.admin.edit', compact('user', 'subjects', 'classes'));
	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update(Request $request, string $id)
	{
		$this->validate($request, [
			'role'		=> 'required|string',
			'email'		=> 'required|email',
			'contact'		=> 'required|numeric',
		]);

		$user = User::findOrFail($id);
		// get form image
		$image = $request->file('image');
		$slug = Str::slug($request->name);

		if (isset($image)) {
			// make unique name for image
			$imageName = $slug . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
			// check post dir is exists
			if (!Storage::disk('public')->exists('user')) {
				Storage::disk('public')->makeDirectory('user');
			}
			// check post dir and delete old photo
			if (!Storage::disk('public')->exists('user/' . $user->image)) {
				Storage::disk('public')->makeDirectory('user/' . $user->image);
			}
			// resize image for post add upload
			$resizeImage = Image::make($image)->resize(160, 160)->stream();
			Storage::disk('public')->put('user/' . $imageName, $resizeImage);
		} else {
			$imageName = $user->image;
		}

		$user->class_id = $request->class_id;
		$user->subject_id = $request->subject_id;
		$user->name = $request->name;
		$user->role = $request->role;
		$user->email = $request->email;
		$user->contact = $request->contact;
		$user->image = $imageName;
		$user->password = Hash::make('12345678');

		$user->title 		=	$request->title;
		$user->facebook 		=	$request->facebook;
		$user->twitter 		=	$request->twitter;
		$user->instagram 		=	$request->instagram;

		$user->roll = $request->roll;
		$user->register = $request->register;
		$user->father_name = $request->father_name;
		$user->mother_name = $request->mother_name;
		$user->guardian_contact = $request->guardian_contact;
		$user->present_address = $request->present_address;
		$user->parament_address = $request->parament_address;
		$user->session = $request->session;
		$user->gender  =  $request->gender;
		$user->teacher_type  =  true;

		if (isset($request->status)) {
			$user->status = true;
		} else {
			$user->status = true;
		}

		$user->update();

		Toastr::success('You have Update the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(string $id)
	{
		$user = User::findOrFail($id);
		// check post dir and delete old photo
		if (!Storage::disk('public')->exists('user/' . $user->image)) {
			Storage::disk('public')->makeDirectory('user/' . $user->image);
		}
		$user->delete();

		Toastr::success('You have Delete the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Display a listing of the resource.
	 */
	public function teachers()
	{
		// $teacher = User::where('role', 'teacher')->latest()->get();
		$teacher = UserTeacher::latest()->get();
		return view('admin.user.teacher.index', compact('teacher'));
	}

	/**
	 * Display a listing of the resource.
	 */
	public function students()
	{
		$students = User::where('role', 'user')->latest()->get();
		return view('admin.user.student.index', compact('students'));
	}
}
