<?php

namespace App\Http\Controllers\Admin;

use App\Models\Student;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Batch;
use Brian2694\Toastr\Facades\Toastr;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;

class StudentController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index()
	{
		$students = Student::latest()->get();
		return view('admin.students.index', compact('students'));
	}

	/**
	 * Show the form for creating a new resource.
	 */
	public function create()
	{
		$batches = Batch::get();
		return view('admin.students.create', compact('batches'));
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(Request $request)
	{
		$this->validate($request, [
			'name'		=> 'required|string',
			'father_name'		=> 'required|string',
			'mother_name'		=> 'required|string',
			'guardian_contact'		=> 'required',
			'roll'		=> 'required',
			'class_id'		=> 'required',
			'register'		=> 'required',
			'session'		=> 'required',
			'image'		=> 'required|mimes:png,jpg,jpeg,webp|max:3024',
		]);


		// get form image
		$image = $request->file('image');
		$slug = Str::slug($request->name);

		if (isset($image)) {
			// make unique name for image
			$imageName = $slug . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
			// check post dir is exists
			if (!Storage::disk('public')->exists('students')) {
				Storage::disk('public')->makeDirectory('students');
			}
			// resize image for post add upload
			$resizeImage = Image::make($image)->resize(360, 360)->stream();
			Storage::disk('public')->put('students/' . $imageName, $resizeImage);
		} else {
			$imageName = 'default.png';
		}

		$students = new Student();
		$students->class_id = $request->class_id;
		$students->name = $request->name;
		$students->slug = $slug;
		$students->roll = $request->roll;
		$students->register = $request->register;
		$students->father_name = $request->father_name;
		$students->mother_name = $request->mother_name;
		$students->guardian_contact = $request->guardian_contact;
		$students->present_address = $request->present_address;
		$students->parament_address = $request->parament_address;
		$students->session = $request->session;
		$students->gender  =  $request->gender;
		$students->image  =  $imageName;

		if (isset($request->status)) {
			$students->status = true;
		} else {
			$students->status = false;
		}

		$students->save();

		Toastr::success('You have Create the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Display the specified resource.
	 */
	public function show(string $id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 */
	public function edit(string $id)
	{
		$batches = Batch::latest()->get();
		$student = Student::findOrFail($id);
		return view('admin.students.edit', compact('student', 'batches'));
	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update(Request $request, string $id)
	{
		$this->validate($request, [
			'name'		=> 'required|string',
			'father_name'		=> 'required|string',
			'mother_name'		=> 'required|string',
			'guardian_contact'		=> 'required',
			'roll'		=> 'required',
			'class_id'		=> 'required',
			'register'		=> 'required',
			'session'		=> 'required',
			'image'		=> 'mimes:png,jpg,jpeg,webp|max:3024',
		]);


		$students = Student::findOrFail($id);
		// get form image
		$image = $request->file('image');
		$slug = Str::slug($request->name);

		if (isset($image)) {
			// make unique name for image
			$imageName = $slug . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
			// check post dir is exists
			if (!Storage::disk('public')->exists('students')) {
				Storage::disk('public')->makeDirectory('students');
			}
			//Old image delete in file
			if (Storage::disk('public')->exists('students/' . $students->image)) {
				Storage::disk('public')->delete('students/' . $students->image);
			}
			// resize image for post add upload
			$resizeImage = Image::make($image)->resize(360, 360)->stream();
			Storage::disk('public')->put('students/' . $imageName, $resizeImage);
		} else {
			$imageName = $students->image;
		}

		$students->class_id = $request->class_id;
		$students->name = $request->name;
		$students->slug = $slug;
		$students->roll = $request->roll;
		$students->register = $request->register;
		$students->father_name = $request->father_name;
		$students->mother_name = $request->mother_name;
		$students->guardian_contact = $request->guardian_contact;
		$students->present_address = $request->present_address;
		$students->parament_address = $request->parament_address;
		$students->session = $request->session;
		$students->gender  =  $request->gender;
		$students->image  =  $imageName;

		if (isset($request->status)) {
			$students->status = true;
		} else {
			$students->status = false;
		}

		$students->update();

		Toastr::success('You have Update the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(string $id)
	{
		$students = Student::findOrFail($id);
		//Old image delete in file
		if (Storage::disk('public')->exists('students/' . $students->image)) {
			Storage::disk('public')->delete('students/' . $students->image);
		}
		$students->delete();
		Toastr::success('You have Update the data Successfully', 'Success');
		return redirect()->back();
	}
}
