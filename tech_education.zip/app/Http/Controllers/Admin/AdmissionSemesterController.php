<?php

namespace App\Http\Controllers\Admin;

use App\Models\Admission;
use Illuminate\Http\Request;
use App\Models\AdmissionSemester;
use App\Http\Controllers\Controller;
use App\Models\AdmissionDetails;
use Brian2694\Toastr\Facades\Toastr;

class AdmissionSemesterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $semesters = AdmissionSemester::latest()->get();
        return view('admin.admission.semester.index', compact('semesters'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $admissions = Admission::latest()->get();
        $semesters = AdmissionDetails::latest()->get();
        return view('admin.admission.semester.create', compact('admissions', 'semesters'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'semester' => 'required|string'
        ]);

        $semester = new AdmissionSemester();
        $semester->admission_id = $request->admission_id;
        $semester->admission_details_id = $request->admission_details_id;
        $semester->semester = $request->semester;

        $semester->save();

        Toastr::success('You have Create the data Successfully', 'Success');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        return view('admin.admission.semester.show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $admissions = Admission::latest()->get();
        $semesters_details = AdmissionDetails::latest()->get();
        $semesters = AdmissionSemester::findOrFail($id);
        return view('admin.admission.semester.edit', compact('admissions', 'semesters_details', 'semesters'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $this->validate($request, [
            'semester' => 'required|string'
        ]);

        $semester = AdmissionSemester::findOrFail($id);
        $semester->admission_id = $request->admission_id;
        $semester->admission_details_id = $request->admission_details_id;
        $semester->semester = $request->semester;

        $semester->update();

        Toastr::success('You have Update the data Successfully', 'Success');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $semester = AdmissionSemester::findOrFail($id);
        $semester->delete();
        Toastr::success('You have Delete the data Successfully', 'Success');
        return redirect()->back();
    }
}