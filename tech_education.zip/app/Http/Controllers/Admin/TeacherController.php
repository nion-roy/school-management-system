<?php

namespace App\Http\Controllers\Admin;

use App\Models\Teacher;
use App\Models\Admission;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Subject;
use App\Models\TeacherTab;
use Brian2694\Toastr\Facades\Toastr;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;

class TeacherController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index()
	{
		$teachers = Teacher::latest()->get();
		return view('admin.teacher.index', compact('teachers'));
	}

	/**
	 * Show the form for creating a new resource.
	 */
	public function create()
	{
		$tabs = TeacherTab::latest()->get();
		return view('admin.teacher.create', compact('tabs'));
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(Request $request)
	{
		$this->validate($request, [
			'name'		=> 'required|string',
			'title'		=> 'required|string',
			'tab_id'		=> 'required|string',
			'image'		=> 'required|image|mimes:png,jpg,jpeg,webp|max:3072'
		]);

		// get form image
		$image = $request->file('image');
		$slug = Str::slug($request->name);

		if (isset($image)) {
			// make unique name for image
			$imageName = $slug . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
			// check post dir is exists
			if (!Storage::disk('public')->exists('teacher')) {
				Storage::disk('public')->makeDirectory('teacher');
			}
			// resize image for post add upload
			$resizeImage = Image::make($image)->resize(550, 650)->stream();
			Storage::disk('public')->put('teacher/' . $imageName, $resizeImage);
		} else {
			$imageName = 'default.png';
		}

		$teacher = new Teacher();
		$teacher->name 		=	$request->name;
		$teacher->title 		=	$request->title;
		$teacher->image 		=	$imageName;
		$teacher->slug 		=	$slug;
		$teacher->facebook 		=	$request->facebook;
		$teacher->twitter 		=	$request->twitter;
		$teacher->instagram 		=	$request->instagram;
		$teacher->tab_id 		=	$request->tab_id;

		if (isset($request->status)) {
			$teacher->status = true;
		} else {
			$teacher->status = false;
		}

		$teacher->save();

		Toastr::success('You have Create the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Display the specified resource.
	 */
	public function show(string $id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 */
	public function edit(string $id)
	{
		$teachers = Teacher::findOrFail($id);
		$tab = TeacherTab::latest()->get();
		return view('admin.teacher.edit', compact('teachers', 'tab'));
	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update(Request $request, string $id)
	{
		$this->validate($request, [
			'name'		=> 'required|string',
			'title'		=> 'required|string',
			'tab_id'		=> 'required|string',
			'image'		=> 'image|mimes:png,jpg,jpeg,webp|max:3072'
		]);

		$teacher = Teacher::findOrFail($id);
		// get form image
		$image = $request->file('image');
		$slug = Str::slug($request->name);

		if (isset($image)) {
			// make unique name for image
			$imageName = $slug . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
			// check post dir is exists
			if (!Storage::disk('public')->exists('teacher')) {
				Storage::disk('public')->makeDirectory('teacher');
			}
			//Delete image on file
			if (Storage::disk('public')->exists('teacher/' . $teacher->image)) {
				Storage::disk('public')->delete('teacher/' . $teacher->image);
			}

			// resize image for post add upload
			$resizeImage = Image::make($image)->resize(550, 650)->stream();
			Storage::disk('public')->put('teacher/' . $imageName, $resizeImage);
		} else {
			$imageName = $teacher->image;
		}

		$teacher->name 		=	$request->name;
		$teacher->title 		=	$request->title;
		$teacher->image 		=	$imageName;
		$teacher->slug 		=	$slug;
		$teacher->facebook 		=	$request->facebook;
		$teacher->twitter 		=	$request->twitter;
		$teacher->instagram 		=	$request->instagram;
		$teacher->tab_id 		=	$request->tab_id;

		if (isset($request->status)) {
			$teacher->status = true;
		} else {
			$teacher->status = false;
		}

		$teacher->save();

		Toastr::success('You have Update the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(string $id)
	{
		$teacher = Teacher::findOrFail($id);

		//Delete image on file
		if (Storage::disk('public')->exists('teacher/' . $teacher->image)) {
			Storage::disk('public')->delete('teacher/' . $teacher->image);
		}

		$teacher->delete();

		Toastr::success('You have Delete the data Successfully', 'Success');
		return redirect()->back();
	}
}
