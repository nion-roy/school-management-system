<?php

namespace App\Http\Controllers\Admin;

use App\Models\Admission;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;

class AdmissionController extends Controller
{
	/**
	 * Display a listing of the resource.
	 */
	public function index()
	{
		$admissions = Admission::latest()->get();
		return view('admin.admission.admission.index', compact('admissions'));
	}

	/**
	 * Show the form for creating a new resource.
	 */
	public function create()
	{
		return view('admin.admission.admission.create');
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(Request $request)
	{
		$this->validate($request, [
			'name'      => 'required|string|unique:admissions',
		]);

		$admission = new Admission();
		$admission->name    =   $request->name;
		$admission->slug    =   Str::slug($request->name);

		if (isset($request->status)) {
			$admission->status = true;
		} else {
			$admission->status = false;
		}

		$admission->save();

		Toastr::success('You have Create the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Display the specified resource.
	 */
	public function show(string $id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 */
	public function edit(string $id)
	{
		$admissions = Admission::findOrFail($id);
		return view('admin.admission.admission.edit', compact('admissions'));
	}

	/**
	 * Update the specified resource in storage.
	 */
	public function update(Request $request, string $id)
	{
		$this->validate($request, [
			'name'      => 'required|string',
		]);

		$admission = Admission::findOrFail($id);
		$admission->name    =   $request->name;
		$admission->slug    =   Str::slug($request->name);

		if (isset($request->status)) {
			$admission->status = true;
		} else {
			$admission->status = false;
		}

		$admission->update();

		Toastr::success('You have Update the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(string $id)
	{
		$admission = Admission::findOrFail($id);
		$admission->delete();
		Toastr::success('You have Delete the data Successfully', 'Success');
		return redirect()->back();
	}
}
