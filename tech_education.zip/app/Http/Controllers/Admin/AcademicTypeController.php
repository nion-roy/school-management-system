<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Str;
use App\Models\AcademicType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;

class AcademicTypeController extends Controller
{
	public function typeAcademic()
	{
		$typeAcademic = AcademicType::latest()->get();
		return view('admin.academic.academic-type.index', compact('typeAcademic'));
	}

	/**
	 * Store a newly created resource in storage.
	 */
	public function store(Request $request)
	{
		$this->validate($request, [
			'type'		=> 'required|string'
		]);

		$type = new AcademicType();
		$type->type = $request->type;
		$type->slug = Str::slug($request->type);

		$type->save();

		Toastr::success('You have Create the data Successfully', 'Success');
		return redirect()->back();
	}

	/**
	 * Remove the specified resource from storage.
	 */
	public function destroy(string $id)
	{
		AcademicType::findOrFail($id)->delete();
		Toastr::success('You have Delete the data Successfully', 'Success');
		return redirect()->back();
	}
}
