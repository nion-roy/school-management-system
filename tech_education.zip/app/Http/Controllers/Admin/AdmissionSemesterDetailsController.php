<?php

namespace App\Http\Controllers\Admin;

use App\Models\Admission;
use Illuminate\Http\Request;
use App\Models\AdmissionDetails;
use App\Models\AdmissionSemester;
use App\Http\Controllers\Controller;
use App\Models\AdmissionSemesterDetails;
use Brian2694\Toastr\Facades\Toastr;

class AdmissionSemesterDetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $semesters = AdmissionSemesterDetails::latest()->get();
        return view('admin.admission.semester-details.index', compact('semesters'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $admissions = Admission::latest()->get();
        $admission_details = AdmissionDetails::latest()->get();
        $admission_semesters = AdmissionSemester::latest()->get();
        return view('admin.admission.semester-details.create', compact('admissions', 'admission_details', 'admission_semesters'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'code_no' => 'required|integer|unique:admission_semester_details',
            'crouse_title' => 'required|string|unique:admission_semester_details',
            'credit' => 'required|string',
            'semester_id' => 'required|integer',
        ]);

        $semester_details = new AdmissionSemesterDetails();
        $semester_details->admission_id = $request->admission_id;
        $semester_details->admission_details_id = $request->admission_details_id;
        $semester_details->semester_id = $request->semester_id;
        $semester_details->code_no = $request->code_no;
        $semester_details->crouse_title = $request->crouse_title;
        $semester_details->credit = $request->credit;

        $semester_details->save();

        Toastr::success('You have Create the data Successfully', 'Success');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $admissions = Admission::latest()->get();
        $admission_details = AdmissionDetails::latest()->get();
        $admission_semesters = AdmissionSemester::latest()->get();
        $semesters = AdmissionSemesterDetails::findOrFail($id);
        return view('admin.admission.semester-details.edit', compact('admissions', 'admission_details', 'admission_semesters', 'semesters'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $this->validate($request, [
            'code_no' => 'required|integer',
            'crouse_title' => 'required|string',
            'credit' => 'required|string',
            'semester_id' => 'required|integer',
        ]);

        $semester_details = AdmissionSemesterDetails::findOrFail($id);
        $semester_details->admission_id = $request->admission_id;
        $semester_details->admission_details_id = $request->admission_details_id;
        $semester_details->semester_id = $request->semester_id;
        $semester_details->code_no = $request->code_no;
        $semester_details->crouse_title = $request->crouse_title;
        $semester_details->credit = $request->credit;

        $semester_details->update();

        Toastr::success('You have Update the data Successfully', 'Success');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $semester_details = AdmissionSemesterDetails::findOrFail($id);
        $semester_details->delete();
        Toastr::success('You have Delete the data Successfully', 'Success');
        return redirect()->back();
    }
}
