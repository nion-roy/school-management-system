<?php

namespace App\Http\Controllers\Admin;

use App\Models\Admission;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\AdmissionDetails;
use App\Models\AdmissionSemester;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Storage;

class AdmissionDetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $admissions_info = AdmissionDetails::latest()->get();
        return view('admin.admission.admission-details.index', compact('admissions_info'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $admissions = Admission::latest()->get();
        return view('admin.admission.admission-details.create', compact('admissions'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'subject' => 'required|string|unique:admission_details',
            'duration' => 'required|string',
            'semester' => 'required|string',
            'header' => 'required|string',
            'overview' => 'required|string',
            'image'  => 'required|image|mimes:png,jpg,jpeg,webp|max:3072'
        ]);


        // get form image
        $image = $request->file('image');
        $slug = Str::slug($request->subject);

        if (isset($image)) {
            // make unique name for image
            $imageName = $slug . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
            // check post dir is exists
            if (!Storage::disk('public')->exists('admission')) {
                Storage::disk('public')->makeDirectory('admission');
            }
            if (!Storage::disk('public')->exists('admission/thumbnail')) {
                Storage::disk('public')->makeDirectory('admission/thumbnail');
            }
            // resize image for post add upload
            $resizeImage = Image::make($image)->resize(640, 420)->stream();
            Storage::disk('public')->put('admission/' . $imageName, $resizeImage);

            $resizeImage = Image::make($image)->resize(440, 320)->stream();
            Storage::disk('public')->put('admission/thumbnail/' . $imageName, $resizeImage);
        } else {
            $imageName = 'default.png';
        }

        $details = new AdmissionDetails();

        $details->admission_id  = $request->admission_id;
        $details->subject  = $request->subject;
        $details->duration  = $request->duration;
        $details->semester  = $request->semester;
        $details->header  = $request->header;
        $details->overview  = $request->overview;
        $details->slug   = $slug;
        $details->image   = $imageName;

        if (isset($request->status)) {
            $details->status = true;
        } else {
            $details->status = false;
        }

        $details->save();

        Toastr::success('You have Create the data Successfully', 'Success');
        return redirect()->back();

        // return $request;
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $ad_info = AdmissionDetails::findOrFail($id);
        $admissions = Admission::latest()->get();
        return view('admin.admission.admission-details.edit', compact('ad_info', 'admissions'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $this->validate($request, [
            'subject' => 'required|string',
            'duration' => 'required|string',
            'semester' => 'required|string',
            'header' => 'required|string',
            'overview' => 'required|string',
            'image'  => 'image|mimes:png,jpg,jpeg,webp|max:3072'
        ]);

        $details = AdmissionDetails::findOrFail($id);
        // get form image
        $image = $request->file('image');
        $slug = Str::slug($request->subject);

        if (isset($image)) {
            // make unique name for image
            $imageName = $slug . '-' . uniqid() . '.' . $image->getClientOriginalExtension();
            // check post dir is exists
            if (!Storage::disk('public')->exists('admission')) {
                Storage::disk('public')->makeDirectory('admission');
            }
            if (!Storage::disk('public')->exists('admission/thumbnail')) {
                Storage::disk('public')->makeDirectory('admission/thumbnail');
            }
            //Old image delete in file
            if (Storage::disk('public')->exists('admission/' . $details->image)) {
                Storage::disk('public')->delete('admission/' . $details->image);
            }
            if (Storage::disk('public')->exists('admission/thumbnail/' . $details->image)) {
                Storage::disk('public')->delete('admission/thumbnail/' . $details->image);
            }
            // resize image for post add upload
            $resizeImage = Image::make($image)->resize(640, 420)->stream();
            Storage::disk('public')->put('admission/' . $imageName, $resizeImage);

            $resizeImage = Image::make($image)->resize(440, 320)->stream();
            Storage::disk('public')->put('admission/thumbnail/' . $imageName, $resizeImage);
        } else {
            $imageName = $details->image;
        }

        $details->admission_id  = $request->admission_id;
        $details->subject  = $request->subject;
        $details->duration  = $request->duration;
        $details->semester  = $request->semester;
        $details->header  = $request->header;
        $details->overview  = $request->overview;
        $details->slug   = $slug;
        $details->image   = $imageName;

        if (isset($request->status)) {
            $details->status = true;
        } else {
            $details->status = false;
        }

        $details->update();

        Toastr::success('You have Update the data Successfully', 'Success');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $details = AdmissionDetails::findOrFail($id);
        //Old image delete in file
        if (Storage::disk('public')->exists('admission/' . $details->image)) {
            Storage::disk('public')->delete('admission/' . $details->image);
        }
        $details->delete();
        Toastr::success('You have Update the data Successfully', 'Success');
        return redirect()->back();
    }
}
